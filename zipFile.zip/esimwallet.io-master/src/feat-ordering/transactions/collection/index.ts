export const TransactionsCollectionId = 'transactions' as const;

import React from 'react';

import { Textual } from '@/components/ui/textual';

interface MyWalletPageProps {}

/**
 * Main *My Wallet* page
 */
export const WalletPage: React.FC<MyWalletPageProps> = () => {
  return (
    <>
      <Textual>Lorem ipsum dolor</Textual>
    </>
  );
};

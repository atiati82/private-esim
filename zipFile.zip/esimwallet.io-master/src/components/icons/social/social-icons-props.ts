import { IconProps } from '@/components/icons/IconProps';

export interface SocialIconProps extends IconProps {
  width?: number;
  height?: number;
}

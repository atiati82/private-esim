import React from 'react';

import { IconProps } from '@/components/icons/IconProps';

export const PaymentsVisaLogo: React.FC<IconProps> = ({ className }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="28"
      height="28"
      viewBox="0 0 2304 1536"
      className={className}
    >
      <path
        fill="currentColor"
        d="M1975 862h-138q14-37 66-179l3-9q4-10 10-26t9-26l12 55zM531 797l-58-295q-11-54-75-54H130l-2 13q311 79 403 336m179-349L548 886l-17-89q-26-70-85-129.5T315 579l135 510h175l261-641zm139 642h166l104-642H953zm768-626q-69-27-149-27q-123 0-201 59t-79 153q-1 102 145 174q48 23 67 41t19 39q0 30-30 46t-69 16q-86 0-156-33l-22-11l-23 144q74 34 185 34q130 1 208.5-59t80.5-160q0-106-140-174q-49-25-71-42t-22-38q0-22 24.5-38.5T1455 571q70-1 124 24l15 8zm425-16h-128q-65 0-87 54l-246 588h174l35-96h212q5 22 20 96h154zm262-320v1280q0 52-38 90t-90 38H128q-52 0-90-38t-38-90V128q0-52 38-90t90-38h2048q52 0 90 38t38 90"
      />
    </svg>
  );
};

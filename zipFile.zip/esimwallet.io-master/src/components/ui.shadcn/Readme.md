Folder for only shadcn/ui components.

https://ui.shadcn.com/

Keep our own app components inside `@/components/ui` dir.

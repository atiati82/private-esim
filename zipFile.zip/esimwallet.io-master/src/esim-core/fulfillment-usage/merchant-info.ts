/**
 * Merchant (eSIMwallet) info / status at Supplier's system
 */
export interface MerchantInfo {
  wallet: {
    balance: number;
  };
}

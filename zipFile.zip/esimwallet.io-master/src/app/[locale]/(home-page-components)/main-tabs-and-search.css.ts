import { style } from '@vanilla-extract/css';

import { pageContainer } from '@/styles/layout.css';

export const container = style([pageContainer, {}]);

import { style } from '@vanilla-extract/css';

import { narrowPageContainer } from '@/styles/layout.css';

export const pageWrapper = style([narrowPageContainer, {}]);

import { EsimProductPage } from '@/app/[locale]/(esims)/esim/[destination]/[esim]/page';

export default EsimProductPage;

export const dataOwner = [
  {
    name: 'Christian',
    role: 'CEO & Founder',
    image: '/images/chris.png',
    description:
      'As our CEO, John brings over 20 years of experience in the logistics industry. His visionary leadership has been instrumental in Alliances rapid growth.',
  },
  {
    name: 'Marcin',
    role: 'CTO & Founder',
    image: '/images/marcin.png',
    description:
      'Jane Smith is a highly skilled software engineer with a strong understanding of the eSIM market. She has been working closely with the team for over a decade, bringing a unique blend of technical expertise and strategic vision to the table.',
  },
  {
    name: 'Atti',
    role: 'Marketing Lead & Founder',
    image: '/images/atti.png',
    description:
      'Jane Smith is a highly skilled software engineer with a strong understanding of the eSIM market. She has been working closely with the team for over a decade, bringing a unique blend of technical expertise and strategic vision to the table.',
  },
];

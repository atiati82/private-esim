import NextMyWalletPage from '../page';

export default NextMyWalletPage;

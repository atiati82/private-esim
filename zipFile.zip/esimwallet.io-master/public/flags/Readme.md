Flags from country-flag-icons NPM package.

Copy the optimised flags, as they are in the root of the package folder (inside [node_modules/country-flag-icons/](../../node_modules/country-flag-icons) directory).

Do not copy any .css files here. They aren't needed.
